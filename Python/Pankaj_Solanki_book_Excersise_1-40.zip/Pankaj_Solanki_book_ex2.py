#EX02
name  =  "my name is Pankaj Solanki"
reverse = name.split()
reverse_word = reverse[::-1]
output = " ".join(reverse_word)
print(output)