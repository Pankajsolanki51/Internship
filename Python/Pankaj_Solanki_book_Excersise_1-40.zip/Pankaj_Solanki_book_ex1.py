#EX 01

print("hello world")
#print("Hello python")   we use # for commenting a line commenting mean when 
# we run our code compiler will skip this while executing the code.
