# Print the string "Mary had a little lamb."
print("Mary had a little lamb.")

# Print the string "Its fleece was white as {}." and format it with the word 'snow'
print("Its fleece was white as {}.".format('snow'))

# Print the string "And everywhere that Mary went."
print("And everywhere that Mary went.")

# Print ten consecutive dots ('.')
print("." * 10)  # It repeats the dot character ten times and prints ".........."

# Assign string values to variables
end1 = "C"
end2 = "h"
end3 = "e"
end4 = "e"
end5 = "s"
end6 = "e"
end7 = "B" 
end8 = "u"
end9 = "r"
end10 = "g"
end11 = "e"
end12 = "r"

# Print the concatenated values of end1 to end6, followed by a space, and then the concatenated values of end7 to end12
print(end1 + end2 + end3 + end4 + end5 + end6, end=' ')
print(end7 + end8 + end9 + end10 + end11 + end12)
