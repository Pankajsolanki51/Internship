#q1
x = 10
y = 5

# Equal to
if x == y:
    print("x is equal to y")

# Not equal to
if x != y:
    print("x is not equal to y")

# Greater than
if x > y:
    print("x is greater than y")

# Less than
if x < y:
    print("x is less than y")

# Greater than or equal to
if x >= y:
    print("x is greater than or equal to y")

# Less than or equal to
if x <= y:
    print("x is less than or equal to y")


#q2
'''== is called "equal to" operator.
!= is called "not equal to" operator.
> is called "greater than" operator.
< is called "less than" operator.
>= is called "greater than or equal to" operator.
<= is called "less than or equal to" operator.'''